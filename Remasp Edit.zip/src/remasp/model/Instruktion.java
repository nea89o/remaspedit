package remasp.model;

public interface Instruktion {
	void eval(Konfiguration paramKonfiguration) throws Exception;
}
